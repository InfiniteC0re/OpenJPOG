The exe file is a complete copy of the original exe, but TApplication.dll was replaced with TAppModCore.dll to make no effect on the original game after installing the modloader.

TAppModCore.dll is a wrapper for TApplication.dll which also injects JPOGModCore.dll to make the modloader work.