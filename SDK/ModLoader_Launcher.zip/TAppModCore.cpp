#include <windows.h>
#include <stdio.h>

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!! Needs manual patching of the constructors and the destructor !!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

HINSTANCE mHinst = 0, mHinstDLL = 0;

UINT_PTR mProcs[17] = { 0 };

LPCSTR mImportNames[] = {
	"??0TApplication@Toshi@@QAE@ABV01@@Z",
	"??0TApplication@Toshi@@QAE@XZ",
	"??1TApplication@Toshi@@UAE@XZ",
	"??4TApplication@Toshi@@QAEAAV01@AAV01@@Z",
	"??_7TApplication@Toshi@@6B@",
	"?Create@TApplication@Toshi@@QAE_NPBDHQAPAD@Z",
	"?Destroy@TApplication@Toshi@@QAEXXZ",
	"?DisplayErrorMessageBox@TApplication@Toshi@@QAEXVTCString@2@@Z=",
	"?Execute@TApplication@Toshi@@QAE_NXZ",
	"?GetKernel@TApplication@Toshi@@QAEPAVTKernelInterface@2@XZ",
	"?IsCreated@TApplication@Toshi@@QAE_NXZ",
	"?OnCreate@TApplication@Toshi@@UAE_NHQAPAD@Z",
	"?OnDestroy@TApplication@Toshi@@UAE_NXZ",
	"?OnUpdate@TApplication@Toshi@@UAE_NM@Z",
	"?SetVerbose@TApplication@Toshi@@QAEX_N@Z",
	"?ShowConsole@TApplication@Toshi@@QAE_N_N@Z",
	"?ToggleConsole@TApplication@Toshi@@QAE_NXZ"
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
	mHinst = hinstDLL;
	if (fdwReason == DLL_PROCESS_ATTACH) {
		mHinstDLL = LoadLibrary("TApplication.dll");
		if (!mHinstDLL) {
			return FALSE;
		}
		for (int i = 0; i < 17; ++i) {
			mProcs[i] = (UINT_PTR)GetProcAddress(mHinstDLL, mImportNames[i]);
		}
	}
	else if (fdwReason == DLL_PROCESS_DETACH) {

		FreeLibrary(mHinstDLL);
	}

	LoadLibrary("JPOGModCore.dll");
	return TRUE;
}

namespace Toshi
{
	class TKernelInterface;

	struct TCString
	{
		int a, b, c, d;
	};

	class __declspec(dllexport) TApplication
	{
	public:
		__thiscall TApplication();
		__thiscall TApplication(const TApplication&);
		virtual __thiscall ~TApplication();

		TApplication& __thiscall operator=(const TApplication&);
		bool  __thiscall Create(char const* data1, int data2, char** const);
		void  __thiscall Destroy();
		void  __thiscall DisplayErrorMessageBox(struct Toshi::TCString);
		bool  __thiscall Execute();
		TKernelInterface* __thiscall GetKernel();
		bool  __thiscall IsCreated();
		virtual bool __thiscall OnCreate(int data1, char** const);
		virtual bool __thiscall OnDestroy();
		virtual bool __thiscall OnUpdate(float);
		void  __thiscall SetVerbose(bool);
		bool  __thiscall ShowConsole(bool);
		bool  __thiscall ToggleConsole();

	private:
		void* a, * b;
	};

	__declspec(naked) TApplication::TApplication()
	{
		__asm {jmp mProcs[1 * 4]}
	}

	__declspec(naked) TApplication::TApplication(const TApplication&)
	{
		__asm {jmp mProcs[0 * 4]}
	}

	__declspec(naked) TApplication::~TApplication()
	{
		__asm {jmp mProcs[2 * 4]}
	}

	__declspec(naked) TApplication& TApplication::operator=(const TApplication&) { __asm {jmp mProcs[3 * 4]} }
	__declspec(naked) bool TApplication::Create(char const* data1, int data2, char** const) { __asm {jmp mProcs[5 * 4]} }
	__declspec(naked) void TApplication::Destroy() { __asm {jmp mProcs[6 * 4]} }
	__declspec(naked) void TApplication::DisplayErrorMessageBox(class Toshi::TCString) { __asm {jmp mProcs[7 * 4]} }
	__declspec(naked) bool TApplication::Execute() { __asm {jmp mProcs[8 * 4]} }
	__declspec(naked) TKernelInterface* TApplication::GetKernel() { __asm {jmp mProcs[9 * 4]} }
	__declspec(naked) bool TApplication::IsCreated() { __asm {jmp mProcs[10 * 4]} }
	__declspec(naked) bool TApplication::OnCreate(int data1, char** const) { __asm {jmp mProcs[11 * 4]} }
	__declspec(naked) bool TApplication::OnDestroy() { __asm {jmp mProcs[12 * 4]} }
	__declspec(naked) bool TApplication::OnUpdate(float) { __asm {jmp mProcs[13 * 4]} }
	__declspec(naked) void TApplication::SetVerbose(bool) { __asm {jmp mProcs[14 * 4]} }
	__declspec(naked) bool TApplication::ShowConsole(bool) { __asm {jmp mProcs[15 * 4]} }
	__declspec(naked) bool TApplication::ToggleConsole() { __asm {jmp mProcs[16 * 4]} }
}
